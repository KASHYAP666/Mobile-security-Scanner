# 🚀 Quick Execution Guide

## Step-by-Step Setup and Execution

### ⚡ Quick Start (5 Minutes)

#### Step 1: Extract Project
```bash
# Extract the ZIP file
unzip mobile-security-scanner.zip
cd mobile-security-scanner
```

#### Step 2: Install Python Dependencies
```bash
# Navigate to backend
cd backend

# Install required packages
pip install Flask==3.0.0 flask-cors==4.0.0 Werkzeug==3.0.1

# Or use requirements.txt
pip install -r requirements.txt
```

#### Step 3: Start Backend Server
```bash
# Make sure you're in backend folder
python app.py

# You should see:
# * Running on http://0.0.0.0:5000
```

#### Step 4: Open Frontend
```bash
# Open a new terminal/command prompt
cd ../frontend

# Option 1: Direct Browser (Easiest)
# Just double-click index.html or open it in browser

# Option 2: Local Server (Recommended)
python -m http.server 8000
# Then open: http://localhost:8000
```

#### Step 5: Test the Application
1. Open browser at `http://localhost:8000` (or open index.html)
2. You'll see the APK Security Scanner interface
3. Try uploading an APK file
4. Click "Start Security Scan"
5. View results and download report

---

## 🎯 For Project Demonstration

### Demo Preparation Checklist

**Before Demo:**
- [ ] Backend server running (python app.py)
- [ ] Frontend accessible in browser
- [ ] Have a sample APK file ready
- [ ] Test upload functionality
- [ ] Verify results display correctly

**During Demo:**
1. **Show the Interface** (30 seconds)
   - Clean, modern design
   - Upload area with drag-and-drop

2. **Upload APK** (30 seconds)
   - Drag file or browse
   - Show file validation

3. **Run Analysis** (30-60 seconds)
   - Start scan button
   - Progress bar animation
   - Stage-wise updates

4. **Show Results** (2 minutes)
   - Summary statistics
   - Vulnerability cards
   - Risk levels (High/Medium/Low)
   - Detailed descriptions

5. **Download Report** (30 seconds)
   - Click download button
   - Show generated report

**Total Demo Time:** 4-5 minutes

---

## 🔧 Troubleshooting Quick Fixes

### Problem: "Module not found" error
**Solution:**
```bash
pip install Flask flask-cors Werkzeug
```

### Problem: Port 5000 already in use
**Solution:**
```python
# Edit backend/app.py, line at bottom:
app.run(debug=True, host='0.0.0.0', port=5001)  # Change port

# Also edit frontend/script.js:
const API_URL = 'http://localhost:5001';  # Update port
```

### Problem: CORS errors in browser
**Solution:**
```bash
# Ensure flask-cors is installed
pip install flask-cors

# Or open frontend via file:// protocol (direct double-click)
```

### Problem: Can't upload files
**Solution:**
- Check backend is running: http://localhost:5000
- Check file is .apk format
- Check file size < 100MB
- Try different browser

---

## 📊 Testing Without Real APK

The system has **simulation mode** built-in:
- Works even without APKTool/JADX installed
- Generates realistic vulnerability findings
- Perfect for demo and learning

Just upload any .apk file (or create a dummy one):
```bash
# Create a dummy APK for testing (just for demo)
echo "This is a test APK" > test.apk
```

---

## 🎓 For Viva/Presentation

### Key Points to Remember

**What is the project?**
"A web-based security testing tool that analyzes Android APK files to identify vulnerabilities automatically using reverse engineering techniques."

**Main Features:**
1. Automated vulnerability detection
2. Web-based interface
3. 8+ security check categories
4. Detailed reports with mitigation

**Technologies Used:**
- Frontend: HTML, CSS, JavaScript, Bootstrap
- Backend: Python Flask
- Tools: APKTool, JADX (optional)
- Analysis: Static analysis, pattern matching

**Vulnerabilities Detected:**
- Hardcoded secrets (HIGH)
- Weak encryption (HIGH)
- Missing SSL pinning (HIGH)
- Insecure storage (MEDIUM)
- Debug mode (MEDIUM)
- WebView issues (MEDIUM)
- No obfuscation (LOW)
- Exported components (LOW)

### Quick Demo Script

**Opening:** "I'll demonstrate our APK Security Scanner that identifies vulnerabilities in Android applications."

**Step 1:** "Here's the web interface with a clean, modern design."

**Step 2:** "I'll upload an APK file using drag-and-drop."

**Step 3:** "Clicking 'Start Security Scan' initiates the analysis."

**Step 4:** "The system shows progress through different stages - decompiling, extracting, analyzing."

**Step 5:** "Here are the results categorized by risk level - 3 high-risk, 3 medium-risk, and 2 low-risk issues."

**Step 6:** "Each vulnerability includes description, location, and mitigation strategies."

**Step 7:** "Users can download a comprehensive report for documentation."

**Closing:** "This tool helps developers and students learn about mobile security vulnerabilities and how to fix them."

---

## 📱 Sample APK for Testing

If you don't have an APK:

**Option 1: Create Dummy APK**
```bash
# This won't be analyzed but will trigger simulation mode
echo "dummy" > demo.apk
```

**Option 2: Download Sample Apps**
- F-Droid (open source apps)
- APKPure (app marketplace)
- Your own Android app projects

**Option 3: Use Vulnerable Demo Apps**
- DIVA (Damn Insecure and Vulnerable App)
- InsecureBankv2
- AndroGoat

**Remember:** Only test apps you own or have permission to analyze!

---

## 🎬 Step-by-Step Execution Video Script

**Minute 0:00 - 0:30**
"Opening terminal, navigating to project directory, installing dependencies with pip"

**Minute 0:30 - 1:00**
"Starting Flask backend server, confirming it's running on port 5000"

**Minute 1:00 - 1:30**
"Opening frontend in browser, showing the main interface"

**Minute 1:30 - 2:00**
"Uploading APK file via drag-and-drop, showing file validation"

**Minute 2:00 - 2:30**
"Starting security scan, showing progress bar and status updates"

**Minute 2:30 - 3:30**
"Displaying results: summary statistics and detailed vulnerability cards"

**Minute 3:30 - 4:00**
"Downloading report and opening it to show contents"

**Minute 4:00 - 4:30**
"Explaining one vulnerability in detail with mitigation"

---

## 💡 Pro Tips

### For Better Demo
1. **Pre-test everything** - Run through once before presenting
2. **Have backup** - Screenshots if live demo fails
3. **Explain as you go** - Don't just click, explain each step
4. **Show the code** - Open a code file to show implementation
5. **Highlight features** - Point out unique aspects

### For Better Understanding
1. **Read COMPLETE_PROJECT_REPORT.md** - Understand all concepts
2. **Study VIVA_QUESTIONS.md** - Prepare for questions
3. **Review PPT_CONTENT.md** - Know presentation flow
4. **Practice explaining** - Can you explain to a non-technical person?

### For Better Results
1. **Test with real APKs** - If you have permissions
2. **Compare results** - With other tools like MobSF
3. **Understand limitations** - Know what it can and can't do
4. **Explore code** - Read through analyzer.py

---

## 📋 Pre-Submission Checklist

- [ ] All code files present and working
- [ ] Backend starts without errors
- [ ] Frontend displays correctly
- [ ] Can upload and scan APK
- [ ] Results display properly
- [ ] Report downloads successfully
- [ ] Documentation is complete
- [ ] README explains project
- [ ] Code is commented
- [ ] No sensitive information in code
- [ ] Project structure is organized
- [ ] All requirements listed
- [ ] Ethical disclaimers included

---

## 🎯 Final Checks Before Viva

1. **Technical**
   - [ ] Project runs on fresh system
   - [ ] All dependencies listed
   - [ ] No errors in console
   - [ ] Demo works smoothly

2. **Documentation**
   - [ ] Report is complete
   - [ ] Code is readable
   - [ ] Comments explain logic
   - [ ] References cited

3. **Knowledge**
   - [ ] Can explain architecture
   - [ ] Understand each security check
   - [ ] Know how tools work
   - [ ] Can discuss improvements

4. **Presentation**
   - [ ] Confident explanation
   - [ ] Clear demo flow
   - [ ] Prepared for questions
   - [ ] Professional attitude

---

## 🆘 Emergency Contacts

**If Something Breaks:**

1. **Check Error Messages**
   - Read console output carefully
   - Google the error message
   - Check documentation

2. **Restart Everything**
   - Stop backend (Ctrl+C)
   - Close browser
   - Start backend again
   - Reopen frontend

3. **Use Simulation Mode**
   - Works without external tools
   - Still demonstrates concepts
   - Good for educational demo

4. **Have Backup Screenshots**
   - Show what it should look like
   - Explain what would happen
   - Walk through the workflow

---

## 🎉 Success Indicators

**You're Ready When:**
- ✅ Can start the app in under 2 minutes
- ✅ Can explain each vulnerability type
- ✅ Can demo without notes
- ✅ Can answer "why" questions
- ✅ Understand the code you wrote
- ✅ Can discuss improvements
- ✅ Confident in your knowledge

---

**Good Luck! You've Got This! 🚀**

Remember: This is an educational tool. Always emphasize ethical use and authorized testing only.
