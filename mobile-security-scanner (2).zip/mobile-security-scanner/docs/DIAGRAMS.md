# System Architecture & Diagrams

## 1. System Architecture Diagram

### Three-Tier Architecture

```
╔═══════════════════════════════════════════════════════════════╗
║                     PRESENTATION LAYER                        ║
║                    (Web Browser / Client)                     ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  ┌─────────────────────────────────────────────────────┐     ║
║  │              User Interface (HTML/CSS/JS)           │     ║
║  │                                                      │     ║
║  │  • Upload Interface (Drag & Drop)                   │     ║
║  │  • Progress Indicator & Loading Screen              │     ║
║  │  • Results Dashboard (Vulnerability Cards)          │     ║
║  │  • Download Report Button                           │     ║
║  │  • Statistics Display (High/Medium/Low)             │     ║
║  └─────────────────────────────────────────────────────┘     ║
║                          ↓ HTTP/JSON ↑                        ║
╚═══════════════════════════════════════════════════════════════╝
                                │
╔═══════════════════════════════════════════════════════════════╗
║                     APPLICATION LAYER                         ║
║                    (Flask Backend Server)                     ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  ┌─────────────────────────────────────────────────────┐     ║
║  │                Flask Application                     │     ║
║  │                                                      │     ║
║  │  • POST /analyze (Upload & Process APK)             │     ║
║  │  • POST /download-report (Generate Report)          │     ║
║  │  • GET / (Health Check)                             │     ║
║  │  • GET /tools-check (Verify Tools)                  │     ║
║  │                                                      │     ║
║  │  Components:                                         │     ║
║  │  - Request Handler                                   │     ║
║  │  - File Upload Manager                               │     ║
║  │  - Security Validator                                │     ║
║  │  - Response Builder                                  │     ║
║  └─────────────────────────────────────────────────────┘     ║
║                     ↓ Function Calls ↑                        ║
╚═══════════════════════════════════════════════════════════════╝
                                │
╔═══════════════════════════════════════════════════════════════╗
║                       ANALYSIS LAYER                          ║
║                    (Security Analysis Tools)                  ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  ┌─────────────────────────────────────────────────────┐     ║
║  │              APK Analyzer Module                     │     ║
║  │                                                      │     ║
║  │  1. APK Extraction (ZIP)                            │     ║
║  │     - Extract AndroidManifest.xml                    │     ║
║  │     - Extract DEX files                              │     ║
║  │     - Extract resources                              │     ║
║  │                                                      │     ║
║  │  2. Decompilation (APKTool/JADX)                    │     ║
║  │     - DEX → Smali conversion                         │     ║
║  │     - Resource decoding                              │     ║
║  │     - Optional: Smali → Java                         │     ║
║  │                                                      │     ║
║  │  3. Security Checks                                  │     ║
║  │     ┌───────────────────────────────────┐            │     ║
║  │     │ • Manifest Analysis               │            │     ║
║  │     │ • Hardcoded Secrets Detection     │            │     ║
║  │     │ • Cryptography Check              │            │     ║
║  │     │ • Network Security Review         │            │     ║
║  │     │ • Storage Security Analysis       │            │     ║
║  │     │ • Code Obfuscation Check          │            │     ║
║  │     │ • Component Exposure Check        │            │     ║
║  │     │ • WebView Security Check          │            │     ║
║  │     └───────────────────────────────────┘            │     ║
║  │                                                      │     ║
║  │  4. Results Aggregation                             │     ║
║  │     - Categorize by risk level                       │     ║
║  │     - Add descriptions & locations                   │     ║
║  │     - Include mitigation strategies                  │     ║
║  │                                                      │     ║
║  │  5. Report Generation                               │     ║
║  │     - Format findings                                │     ║
║  │     - Generate statistics                            │     ║
║  │     - Create downloadable report                     │     ║
║  └─────────────────────────────────────────────────────┘     ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
                                │
                                ↓
╔═══════════════════════════════════════════════════════════════╗
║                        DATA STORAGE                           ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  /uploads/        → Uploaded APK files (timestamped)          ║
║  /reports/        → Generated security reports                ║
║  /decompiled/     → Extracted and decompiled APK contents     ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## 2. Data Flow Diagram

### Complete Request-Response Flow

```
┌──────────┐
│          │
│   USER   │
│          │
└────┬─────┘
     │
     │ 1. Access Web Interface
     ↓
┌─────────────────────────┐
│   Frontend (Browser)    │
│                         │
│  • index.html           │
│  • style.css            │
│  • script.js            │
└────┬────────────────────┘
     │
     │ 2. Upload APK File
     │    (Drag & Drop or Browse)
     ↓
┌─────────────────────────┐
│  File Validation        │
│                         │
│  • Check .apk extension │
│  • Verify size < 100MB  │
│  • Create FormData      │
└────┬────────────────────┘
     │
     │ 3. HTTP POST Request
     │    to /analyze endpoint
     ↓
┌─────────────────────────────────────┐
│   Flask Backend Server              │
│                                     │
│   app.py (Main Application)         │
│   ┌─────────────────────────────┐   │
│   │ 4. Receive & Validate       │   │
│   │    - Check file exists      │   │
│   │    - Verify file type       │   │
│   │    - Secure filename        │   │
│   └──────────┬──────────────────┘   │
│              │                       │
│   ┌──────────┴──────────────────┐   │
│   │ 5. Save File Securely       │   │
│   │    timestamp_filename.apk   │   │
│   │    → /uploads/ directory    │   │
│   └──────────┬──────────────────┘   │
│              │                       │
└──────────────┼───────────────────────┘
               │
               ↓
┌──────────────────────────────────────┐
│   analyzer.py (Analysis Module)      │
│                                      │
│   ┌────────────────────────────┐     │
│   │ 6. Initialize Analyzer     │     │
│   │    APKAnalyzer(apk_path)   │     │
│   └──────────┬─────────────────┘     │
│              │                        │
│   ┌──────────┴─────────────────┐     │
│   │ 7. Extract APK (ZIP)       │     │
│   │    • Unzip contents         │     │
│   │    • Read Manifest          │     │
│   │    • Access resources       │     │
│   └──────────┬─────────────────┘     │
│              │                        │
│   ┌──────────┴─────────────────┐     │
│   │ 8. Decompile (Optional)    │     │
│   │    apktool d app.apk       │     │
│   │    → Smali + Resources     │     │
│   └──────────┬─────────────────┘     │
│              │                        │
│   ┌──────────┴─────────────────┐     │
│   │ 9. Run Security Checks     │     │
│   │                            │     │
│   │  ├─ check_manifest()       │     │
│   │  ├─ check_secrets()        │     │
│   │  ├─ check_crypto()         │     │
│   │  ├─ check_network()        │     │
│   │  ├─ check_storage()        │     │
│   │  └─ check_obfuscation()    │     │
│   └──────────┬─────────────────┘     │
│              │                        │
│   ┌──────────┴─────────────────┐     │
│   │ 10. Aggregate Results      │     │
│   │     • Collect findings     │     │
│   │     • Categorize risks     │     │
│   │     • Count statistics     │     │
│   └──────────┬─────────────────┘     │
│              │                        │
└──────────────┼────────────────────────┘
               │
               │ 11. Return Results
               ↓
┌─────────────────────────────────┐
│   JSON Response                 │
│                                 │
│   {                             │
│     "vulnerabilities": [...],   │
│     "total_count": 8,           │
│     "high_count": 3,            │
│     "medium_count": 3,          │
│     "low_count": 2              │
│   }                             │
└────┬────────────────────────────┘
     │
     │ 12. Parse & Display
     ↓
┌─────────────────────────────┐
│   Frontend Display          │
│                             │
│   • Update statistics       │
│   • Create vuln cards       │
│   • Show risk badges        │
│   • Enable download         │
└────┬────────────────────────┘
     │
     │ 13. View Results
     ↓
┌──────────┐
│          │
│   USER   │
│          │
└──────────┘
```

---

## 3. User Flow Diagram

### End-to-End User Journey

```
                     START
                       │
                       ↓
         ┌─────────────────────────┐
         │  Open Web Application   │
         │  (http://localhost:8000)│
         └────────────┬────────────┘
                      │
                      ↓
         ┌─────────────────────────┐
         │   View Upload Interface │
         │   • Clean design        │
         │   • Upload area visible │
         └────────────┬────────────┘
                      │
                      ↓
            ╔═════════════════════╗
            ║  Have APK File?     ║
            ╚═════════┬═══════════╝
                      │
        ┌─────────────┴─────────────┐
        │                           │
       NO                          YES
        │                           │
        ↓                           ↓
┌──────────────────┐    ┌──────────────────────┐
│ Get APK File:    │    │ Select Upload Method │
│ • Download from  │    │                      │
│   app store      │    │  ┌─────────────────┐ │
│ • Use test APK   │    │  │ Method A:       │ │
│ • Create dummy   │    │  │ Drag & Drop     │ │
└────────┬─────────┘    │  └────────┬────────┘ │
         │              │           │          │
         └──────────────┤  ┌────────┴────────┐ │
                        │  │ Method B:       │ │
                        │  │ Browse Files    │ │
                        │  └────────┬────────┘ │
                        └───────────┼──────────┘
                                    │
                                    ↓
                        ┌───────────────────────┐
                        │ File Selected         │
                        │ • Validation runs     │
                        │ • Filename displayed  │
                        │ • Scan button enabled │
                        └──────────┬────────────┘
                                   │
                                   ↓
                        ┌───────────────────────┐
                        │ Click "Start Scan"    │
                        └──────────┬────────────┘
                                   │
                                   ↓
                        ┌───────────────────────┐
                        │ Upload Interface      │
                        │ Hidden                │
                        └──────────┬────────────┘
                                   │
                                   ↓
                        ┌───────────────────────┐
                        │ Loading Screen Shows  │
                        │ • Spinner animation   │
                        │ • Progress bar        │
                        │ • Status messages     │
                        └──────────┬────────────┘
                                   │
                                   ↓
                        ┌───────────────────────┐
                        │ Progress Updates:     │
                        │ 20%  - Decompiling    │
                        │ 40%  - Extracting     │
                        │ 60%  - Analyzing      │
                        │ 80%  - Scanning       │
                        │ 100% - Generating     │
                        └──────────┬────────────┘
                                   │
                                   ↓
                        ┌───────────────────────┐
                        │ Analysis Complete     │
                        │ Loading screen hidden │
                        └──────────┬────────────┘
                                   │
                                   ↓
                        ┌───────────────────────┐
                        │ Results Dashboard     │
                        │ Displayed             │
                        │                       │
                        │ ┌─────────────────┐   │
                        │ │ Statistics:     │   │
                        │ │ • High: 3       │   │
                        │ │ • Medium: 3     │   │
                        │ │ • Low: 2        │   │
                        │ │ • Total: 8      │   │
                        │ └─────────────────┘   │
                        └──────────┬────────────┘
                                   │
                                   ↓
                        ┌───────────────────────┐
                        │ Vulnerability Cards   │
                        │ • Color-coded         │
                        │ • Descriptions        │
                        │ • Locations           │
                        │ • Mitigations         │
                        └──────────┬────────────┘
                                   │
                                   ↓
                      ╔════════════════════╗
                      ║ What Next?         ║
                      ╚═════════┬══════════╝
                                │
              ┌─────────────────┼─────────────────┐
              │                 │                 │
              ↓                 ↓                 ↓
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
    │ Download     │  │ Review Each  │  │ Scan Another │
    │ Report       │  │ Vulnerability│  │ APK          │
    └──────┬───────┘  └──────┬───────┘  └──────┬───────┘
           │                 │                 │
           │                 │                 │
           ↓                 ↓                 │
    ┌──────────────┐  ┌──────────────┐        │
    │ Report.txt   │  │ Understand:  │        │
    │ Downloaded   │  │ • Issue      │        │
    │ to Computer  │  │ • Risk       │        │
    └──────┬───────┘  │ • Fix        │        │
           │          └──────┬───────┘        │
           │                 │                 │
           └─────────────────┴─────────────────┘
                             │
                             ↓
                    ┌────────────────┐
                    │ Take Action:   │
                    │ • Fix issues   │
                    │ • Document     │
                    │ • Re-test      │
                    └────────────────┘
                             │
                             ↓
                           END
```

---

## 4. Component Interaction Diagram

### How Components Communicate

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INTERACTION                         │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ↓
┌────────────────────────────────────────────────────────────┐
│                  FRONTEND COMPONENTS                        │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌─────────────┐  │
│  │  index.html  │───▶│  script.js   │───▶│  style.css  │  │
│  │              │    │              │    │             │  │
│  │ • Structure  │    │ • Logic      │    │ • Styling   │  │
│  │ • Elements   │    │ • Events     │    │ • Animation │  │
│  │ • Layout     │    │ • AJAX calls │    │ • Responsive│  │
│  └──────────────┘    └──────┬───────┘    └─────────────┘  │
│                             │                              │
└─────────────────────────────┼──────────────────────────────┘
                              │
                  ┌───────────┴───────────┐
                  │   XMLHttpRequest /    │
                  │   Fetch API           │
                  │   (HTTP POST/GET)     │
                  └───────────┬───────────┘
                              │
┌─────────────────────────────┼──────────────────────────────┐
│               BACKEND COMPONENTS                            │
├─────────────────────────────┼──────────────────────────────┤
│                             ↓                               │
│  ┌─────────────────────────────────────────────┐            │
│  │             app.py (Main Flask App)         │            │
│  │                                             │            │
│  │  • Routes & Endpoints                       │            │
│  │  • Request validation                       │            │
│  │  • File handling                            │            │
│  │  • Response formatting                      │            │
│  └──────────────┬──────────────┬───────────────┘            │
│                 │              │                            │
│                 ↓              ↓                            │
│  ┌──────────────────┐  ┌────────────────────┐              │
│  │   analyzer.py    │  │ report_generator.py│              │
│  │                  │  │                    │              │
│  │ • APKAnalyzer    │  │ • ReportGenerator  │              │
│  │   class          │  │   class            │              │
│  │                  │  │                    │              │
│  │ Methods:         │  │ Methods:           │              │
│  │ • analyze()      │  │ • generate_text()  │              │
│  │ • extract_apk()  │  │ • generate_pdf()   │              │
│  │ • decompile()    │  │ • format_results() │              │
│  │ • check_*()      │  │                    │              │
│  └────────┬─────────┘  └────────────────────┘              │
│           │                                                 │
└───────────┼─────────────────────────────────────────────────┘
            │
            ↓
┌───────────────────────────────────────────────────────────┐
│              EXTERNAL TOOLS & UTILITIES                    │
├───────────────────────────────────────────────────────────┤
│                                                            │
│  ┌──────────┐    ┌──────────┐    ┌────────────────┐      │
│  │ APKTool  │    │   JADX   │    │ Python Libs    │      │
│  │          │    │          │    │                │      │
│  │ • Decode │    │ • DEX to │    │ • zipfile      │      │
│  │   APK    │    │   Java   │    │ • subprocess   │      │
│  │ • Smali  │    │ • Deobf. │    │ • re (regex)   │      │
│  └──────────┘    └──────────┘    │ • xml.etree    │      │
│                                   └────────────────┘      │
│                                                            │
└────────────────────────────────────────────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────┐
│                    FILE SYSTEM                             │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  /uploads/          /reports/          /decompiled/        │
│  └─ *.apk           └─ *.txt/.pdf      └─ extracted/       │
│                                            └─ decompiled/   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 5. Security Check Workflow

### How Each Security Check Works

```
┌────────────────────────────────────────────────────────┐
│           SECURITY ANALYSIS WORKFLOW                   │
└───────────────────────┬────────────────────────────────┘
                        │
                        ↓
            ┌───────────────────────┐
            │  Load Decompiled APK  │
            │  • Smali files        │
            │  • Resources          │
            │  • Manifest           │
            └───────────┬───────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ↓               ↓               ↓
┌───────────────┐ ┌───────────┐ ┌──────────────┐
│ CHECK 1:      │ │ CHECK 2:  │ │ CHECK 3:     │
│ Manifest      │ │ Hardcoded │ │ Cryptography │
│ Analysis      │ │ Secrets   │ │              │
│               │ │           │ │              │
│ • Parse XML   │ │ • Regex   │ │ • Find API   │
│ • Check flags │ │   patterns│ │   calls      │
│ • Permissions │ │ • String  │ │ • Check algo │
│ • Components  │ │   search  │ │ • Key size   │
└───────┬───────┘ └─────┬─────┘ └──────┬───────┘
        │               │               │
        └───────────────┼───────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ↓               ↓               ↓
┌───────────────┐ ┌───────────┐ ┌──────────────┐
│ CHECK 4:      │ │ CHECK 5:  │ │ CHECK 6:     │
│ Network       │ │ Storage   │ │ Code Obf.    │
│ Security      │ │ Security  │ │              │
│               │ │           │ │              │
│ • SSL config  │ │ • SharedP.│ │ • Class      │
│ • Cert pin    │ │ • File I/O│ │   names      │
│ • Cleartext   │ │ • Database│ │ • Method     │
│ • WebView     │ │ • Encrypt │ │   names      │
└───────┬───────┘ └─────┬─────┘ └──────┬───────┘
        │               │               │
        └───────────────┼───────────────┘
                        │
                        ↓
            ┌───────────────────────┐
            │  Aggregate Findings   │
            │                       │
            │  For Each Issue:      │
            │  • Title              │
            │  • Risk Level         │
            │  • Description        │
            │  • Location           │
            │  • Mitigation         │
            └───────────┬───────────┘
                        │
                        ↓
            ┌───────────────────────┐
            │  Categorize by Risk   │
            │                       │
            │  HIGH    → Critical   │
            │  MEDIUM  → Important  │
            │  LOW     → Advisory   │
            └───────────┬───────────┘
                        │
                        ↓
            ┌───────────────────────┐
            │  Calculate Statistics │
            │                       │
            │  • Total count        │
            │  • High count         │
            │  • Medium count       │
            │  • Low count          │
            └───────────┬───────────┘
                        │
                        ↓
            ┌───────────────────────┐
            │  Return Results       │
            │  (JSON format)        │
            └───────────────────────┘
```

---

## 6. Database/File Structure Diagram

### File System Organization

```
mobile-security-scanner/
│
├── frontend/                      # Web Interface
│   ├── index.html                 # Main HTML page
│   ├── style.css                  # Styling
│   └── script.js                  # Client-side logic
│
├── backend/                       # Flask Server
│   ├── app.py                     # Main application
│   ├── analyzer.py                # Analysis logic
│   ├── report_generator.py        # Report creation
│   ├── requirements.txt           # Dependencies
│   │
│   ├── uploads/                   # Uploaded APKs
│   │   ├── 20250330_143022_app.apk
│   │   └── 20250330_150115_test.apk
│   │
│   ├── reports/                   # Generated reports
│   │   ├── 20250330_143022_results.json
│   │   ├── report_20250330_143022.txt
│   │   └── report_20250330_150115.txt
│   │
│   └── decompiled/                # Decompiled APKs
│       ├── extracted/             # ZIP extraction
│       │   ├── AndroidManifest.xml
│       │   ├── classes.dex
│       │   ├── resources.arsc
│       │   ├── res/
│       │   └── lib/
│       │
│       └── decompiled/            # APKTool output
│           ├── AndroidManifest.xml
│           ├── apktool.yml
│           ├── smali/             # Smali code
│           │   └── com/example/app/
│           ├── res/               # Resources
│           └── original/          # Original files
│
├── docs/                          # Documentation
│   ├── COMPLETE_PROJECT_REPORT.md # Full report
│   ├── INSTALLATION.md            # Setup guide
│   ├── USAGE.md                   # User guide
│   ├── VIVA_QUESTIONS.md          # Q&A
│   ├── PPT_CONTENT.md             # Presentation
│   ├── DIAGRAMS.md                # This file
│   └── README.md                  # Project overview
│
└── demo/                          # Demo materials
    └── safe_demo.apk.txt          # Demo notes
```

---

## 7. Deployment Diagram

### Production Deployment Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     INTERNET                            │
└────────────────────────┬────────────────────────────────┘
                         │
                         ↓
           ┌─────────────────────────┐
           │   Load Balancer         │
           │   (nginx/Apache)        │
           └────────┬────────────────┘
                    │
        ┌───────────┴───────────┐
        │                       │
        ↓                       ↓
┌──────────────┐       ┌──────────────┐
│ Web Server 1 │       │ Web Server 2 │
│              │       │              │
│ ┌──────────┐ │       │ ┌──────────┐ │
│ │ Frontend │ │       │ │ Frontend │ │
│ │ (Static) │ │       │ │ (Static) │ │
│ └──────────┘ │       │ └──────────┘ │
└──────┬───────┘       └──────┬───────┘
       │                      │
       └──────────┬───────────┘
                  │
                  ↓
      ┌───────────────────────┐
      │  Application Server   │
      │  (Flask + Gunicorn)   │
      │                       │
      │  ┌─────────────────┐  │
      │  │ Flask App       │  │
      │  │ • Route Handler │  │
      │  │ • API Endpoints │  │
      │  └─────────────────┘  │
      │                       │
      │  ┌─────────────────┐  │
      │  │ Worker Processes│  │
      │  │ • APK Analysis  │  │
      │  │ • Decompilation │  │
      │  └─────────────────┘  │
      └───────────┬───────────┘
                  │
        ┌─────────┴─────────┐
        │                   │
        ↓                   ↓
┌───────────────┐   ┌───────────────┐
│ File Storage  │   │ Cache/Redis   │
│               │   │               │
│ • Uploads     │   │ • Results     │
│ • Reports     │   │ • Sessions    │
│ • Decompiled  │   │ • Temp data   │
└───────────────┘   └───────────────┘
```

---

## 8. Risk Classification Flowchart

### How Vulnerabilities are Categorized

```
                    START
                      │
                      ↓
          ┌───────────────────────┐
          │ Vulnerability Found   │
          └───────────┬───────────┘
                      │
                      ↓
        ╔═════════════════════════════╗
        ║ Does it involve credentials ║
        ║ or sensitive data exposure? ║
        ╚═════════════┬═══════════════╝
                      │
          ┌───────────┴───────────┐
         YES                     NO
          │                       │
          ↓                       ↓
    ┌──────────┐         ╔═══════════════╗
    │   HIGH   │         ║ Can it lead to║
    │   RISK   │         ║ MITM attacks? ║
    └──────────┘         ╚═══════┬═══════╝
                                 │
                     ┌───────────┴───────────┐
                    YES                     NO
                     │                       │
                     ↓                       ↓
               ┌──────────┐         ╔═══════════════╗
               │   HIGH   │         ║ Does it allow ║
               │   RISK   │         ║ debugging or  ║
               └──────────┘         ║ inspection?   ║
                                    ╚═══════┬═══════╝
                                            │
                                ┌───────────┴───────────┐
                               YES                     NO
                                │                       │
                                ↓                       ↓
                          ┌──────────┐         ╔═══════════════╗
                          │  MEDIUM  │         ║ Does it make  ║
                          │   RISK   │         ║ reverse eng.  ║
                          └──────────┘         ║ easier?       ║
                                               ╚═══════┬═══════╝
                                                       │
                                           ┌───────────┴───────────┐
                                          YES                     NO
                                           │                       │
                                           ↓                       ↓
                                     ┌──────────┐         ┌──────────┐
                                     │   LOW    │         │   INFO   │
                                     │   RISK   │         │   ONLY   │
                                     └──────────┘         └──────────┘
                                           │                       │
                                           └───────────┬───────────┘
                                                       │
                                                       ↓
                                            ┌──────────────────┐
                                            │ Assign Category  │
                                            │ Add to Results   │
                                            └──────────────────┘
```

---

These diagrams provide a complete visual representation of the system architecture, data flows, user interactions, and component relationships. Use them in your presentation and documentation to explain the system comprehensively.
