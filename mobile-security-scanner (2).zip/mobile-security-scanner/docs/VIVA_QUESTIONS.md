# VIVA Questions and Answers
## APK Security Scanner Project

---

## Basic Questions

### Q1: What is an APK file?

**Answer:** APK stands for Android Package Kit. It is the file format used by Android operating system for distribution and installation of mobile apps. An APK file is essentially a ZIP archive containing:
- Compiled code (classes.dex)
- Resources (images, layouts, strings)
- AndroidManifest.xml (app configuration)
- Libraries and assets
- Signing certificates

### Q2: What is reverse engineering in the context of mobile applications?

**Answer:** Reverse engineering is the process of decompiling or deconstructing an APK file to analyze its source code, resources, and functionality. It involves:
- Extracting the APK contents
- Decompiling DEX bytecode to readable format (Smali or Java)
- Analyzing AndroidManifest.xml
- Examining resources and configurations
This helps in understanding how the app works and identifying security vulnerabilities.

### Q3: Why is mobile security testing important?

**Answer:** Mobile security testing is crucial because:
- Mobile apps handle sensitive data (personal info, financial data, credentials)
- Apps are vulnerable to various attacks (data theft, malware, MITM attacks)
- Regulatory compliance requirements (GDPR, PCI-DSS)
- Protect user privacy and trust
- Prevent financial and reputational damage
- Ensure app quality and reliability

### Q4: What is the difference between static and dynamic analysis?

**Answer:**
**Static Analysis:**
- Examines code without executing it
- Analyzes source code, bytecode, configurations
- Identifies code-level vulnerabilities
- Fast and automated
- Example: Finding hardcoded keys

**Dynamic Analysis:**
- Tests app during runtime
- Monitors behavior, network traffic, memory
- Identifies runtime vulnerabilities
- Requires execution environment
- Example: Detecting actual data leakage

### Q5: What tools did you use in this project?

**Answer:**
1. **APKTool** - Decompiles APK to Smali and resources
2. **JADX** - Converts DEX to readable Java code
3. **Flask** - Python web framework for backend
4. **HTML/CSS/JavaScript** - Frontend interface
5. **Python libraries** - zipfile, subprocess, regex for analysis
6. **Bootstrap** - Responsive UI framework

---

## Technical Questions

### Q6: Explain the architecture of your system.

**Answer:** The system follows a three-tier architecture:

**Tier 1 - Presentation Layer:**
- Web-based interface (HTML, CSS, JavaScript)
- User uploads APK file
- Displays analysis results and reports

**Tier 2 - Application Layer:**
- Flask backend server
- REST API endpoints
- File handling and validation
- Orchestrates analysis process

**Tier 3 - Analysis Layer:**
- APK extraction and decompilation
- Security checks execution
- Vulnerability detection
- Report generation

Data flows from user upload through backend processing to analysis tools and back to the frontend as results.

### Q7: What vulnerabilities does your tool detect?

**Answer:** The tool detects 8 major categories:

**HIGH Risk:**
1. Hardcoded API keys and credentials
2. Weak cryptographic algorithms (MD5, DES)
3. Missing SSL certificate pinning

**MEDIUM Risk:**
4. Insecure data storage (unencrypted SharedPreferences)
5. Debug mode enabled in production
6. Unsafe WebView JavaScript configuration

**LOW Risk:**
7. Missing code obfuscation
8. Exported components without proper permissions

### Q8: How does APKTool work?

**Answer:** APKTool performs several operations:
1. **Decompilation**: Converts DEX bytecode to Smali (assembly language)
2. **Resource Decoding**: Decodes binary XML files to readable format
3. **Extraction**: Extracts all resources, libraries, and assets
4. **Rebuild**: Can rebuild APK from modified Smali/resources

Command: `apktool d app.apk -o output/`

It uses:
- baksmali for DEX to Smali conversion
- Resource decoders for XML and ARSC files
- Maintains project structure for rebuild

### Q9: What is the difference between APKTool and JADX?

**Answer:**

**APKTool:**
- Outputs: Smali (assembly code)
- Purpose: APK modification and rebuilding
- Format: Low-level, harder to read
- Use case: App modification, patching
- Rebuild: Can rebuild APK

**JADX:**
- Outputs: Java source code
- Purpose: Code reading and analysis
- Format: High-level, easier to understand
- Use case: Security analysis, understanding logic
- Rebuild: Cannot rebuild APK

Both are complementary tools for different purposes.

### Q10: How do you detect hardcoded secrets in code?

**Answer:** Multiple techniques:

1. **Regex Patterns:**
   - API key patterns: `sk_live_[A-Za-z0-9]+`
   - URLs with credentials: `http://user:pass@domain`
   - Common variable names: `password`, `api_key`, `secret`

2. **Entropy Analysis:**
   - High entropy strings likely to be secrets
   - Random-looking alphanumeric strings

3. **String Search:**
   - Search strings.xml resources
   - Scan Java/Smali code
   - Check configuration files

4. **Pattern Matching:**
   - AWS keys, Google API keys
   - Database connection strings
   - JWT tokens

---

## Advanced Questions

### Q11: Explain how SSL certificate pinning works and why it's important.

**Answer:** SSL Certificate Pinning is a security technique where the app validates that the server's SSL certificate matches a specific known certificate, rather than trusting any certificate signed by a trusted CA.

**How it works:**
1. App includes hash of expected certificate
2. During TLS handshake, server presents its certificate
3. App compares certificate hash with pinned hash
4. Connection proceeds only if hashes match

**Why important:**
- Prevents MITM attacks even with compromised CAs
- Protects against rogue certificates
- Essential for banking and sensitive apps
- Required for PCI-DSS compliance

**Implementation:**
```java
CertificatePinner pinner = new CertificatePinner.Builder()
    .add("api.example.com", "sha256/AAAA...")
    .build();
```

### Q12: What are the OWASP Mobile Top 10 vulnerabilities?

**Answer:** The OWASP Mobile Top 10 (2024) includes:

1. **M1: Improper Credential Usage** - Hardcoded secrets, weak storage
2. **M2: Inadequate Supply Chain Security** - Third-party SDK risks
3. **M3: Insecure Authentication/Authorization** - Weak login, session management
4. **M4: Insufficient Input/Output Validation** - Injection attacks
5. **M5: Insecure Communication** - Unencrypted data transmission
6. **M6: Inadequate Privacy Controls** - Excessive data collection
7. **M7: Insufficient Binary Protections** - No obfuscation, easy reversing
8. **M8: Security Misconfiguration** - Debug mode, weak settings
9. **M9: Insecure Data Storage** - Unencrypted local storage
10. **M10: Insufficient Cryptography** - Weak algorithms, poor key management

### Q13: What is the Android KeyStore and why is it important?

**Answer:** Android KeyStore is a secure container for cryptographic keys provided by the Android system.

**Features:**
- Hardware-backed security (on supported devices)
- Keys never leave the secure hardware
- Protection against extraction
- Biometric authentication integration

**Why Important:**
- Secure key storage
- Cannot be extracted even on rooted devices
- Ideal for encryption keys, API tokens
- Required for enterprise security

**Usage:**
```java
KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
keyStore.load(null);
KeyGenerator keyGenerator = KeyGenerator.getInstance(
    KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
```

**Best Practices:**
- Store all sensitive keys in KeyStore
- Use hardware backing when available
- Implement key rotation
- Use biometric authentication

### Q14: How would you improve this project?

**Answer:** Several enhancement areas:

**1. Analysis Capabilities:**
- Add dynamic analysis (runtime monitoring)
- Implement behavior analysis
- Add malware detection
- Network traffic analysis

**2. Features:**
- PDF report generation
- Historical analysis tracking
- Comparison between versions
- Integration with CI/CD pipelines

**3. User Interface:**
- Dark mode theme
- Advanced filtering options
- Customizable dashboards
- Mobile-responsive design

**4. Security:**
- User authentication
- Role-based access control
- Encrypted result storage
- Audit logging

**5. Performance:**
- Parallel analysis processing
- Caching mechanisms
- Incremental scanning
- Database integration

**6. Integration:**
- REST API for automation
- IDE plugins
- Bug bounty platform integration
- JIRA/GitHub issue creation

### Q15: What are the limitations of static analysis?

**Answer:** Static analysis has several limitations:

**1. Runtime Behavior:**
- Cannot detect runtime-only vulnerabilities
- Misses dynamic code loading
- Cannot analyze encrypted/obfuscated payloads

**2. Logic Flaws:**
- Cannot understand business logic vulnerabilities
- Misses authentication/authorization bypasses
- Cannot detect race conditions

**3. False Positives:**
- May flag intentional design choices
- Context-dependent findings
- Requires manual verification

**4. Obfuscation:**
- Heavily obfuscated code is hard to analyze
- Native code (C/C++) requires different tools
- Dynamic string construction missed

**5. Coverage:**
- Cannot test all execution paths
- Misses server-side vulnerabilities
- Cannot verify actual exploitation

**Solution:** Combine with dynamic analysis, penetration testing, and manual code review.

---

## Project-Specific Questions

### Q16: How does your system handle file uploads securely?

**Answer:**

**Security Measures:**
1. **File Type Validation:**
   ```python
   allowed_extensions = {'apk'}
   if not file.endswith('.apk'): reject
   ```

2. **Size Limits:**
   ```python
   MAX_CONTENT_LENGTH = 100 * 1024 * 1024  # 100MB
   ```

3. **Secure Filename:**
   ```python
   filename = secure_filename(file.filename)
   timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
   safe_filename = f"{timestamp}_{filename}"
   ```

4. **CORS Configuration:**
   - Restricts cross-origin requests
   - Validates request origins

5. **Input Sanitization:**
   - Werkzeug's secure_filename function
   - Path traversal prevention

### Q17: Walk through the entire analysis workflow.

**Answer:**

**Step 1: File Upload**
- User selects APK file
- Frontend validates file type and size
- File sent to backend via HTTP POST

**Step 2: Backend Processing**
- Flask receives file
- Generates secure filename with timestamp
- Saves to uploads/ directory
- Returns confirmation to frontend

**Step 3: APK Extraction**
- APK treated as ZIP archive
- Extract to temporary directory
- Access AndroidManifest.xml, resources, DEX files

**Step 4: Decompilation**
```python
subprocess.run(['apktool', 'd', '-f', apk_path, '-o', output_dir])
```
- Convert DEX to Smali
- Decode resources
- Extract all components

**Step 5: Security Analysis**
- Execute individual security checks:
  * Manifest analysis (debuggable, permissions)
  * Hardcoded secrets search
  * Cryptography check
  * Storage security review
  * Network configuration analysis
  * Code obfuscation check

**Step 6: Results Aggregation**
```python
results = {
    'vulnerabilities': [...],
    'total_count': 8,
    'high_count': 3,
    'medium_count': 3,
    'low_count': 2
}
```

**Step 7: Report Generation**
- Format vulnerabilities with descriptions
- Add mitigation strategies
- Calculate risk statistics
- Create downloadable report

**Step 8: Frontend Display**
- Receive JSON response
- Parse and categorize findings
- Display in color-coded dashboard
- Enable report download

### Q18: What challenges did you face during development?

**Answer:**

**1. Tool Integration:**
- **Challenge:** APKTool and JADX require system installation
- **Solution:** Implemented simulation mode for demo purposes
- **Learning:** Graceful degradation for missing dependencies

**2. Large File Handling:**
- **Challenge:** APK files can be very large (100MB+)
- **Solution:** Implemented file size limits and streaming uploads
- **Learning:** Resource management and timeout handling

**3. Cross-Origin Issues:**
- **Challenge:** CORS errors when frontend calls backend
- **Solution:** Configured flask-cors properly
- **Learning:** Understanding web security policies

**4. Decompilation Complexity:**
- **Challenge:** Different APK structures and obfuscation levels
- **Solution:** Error handling and fallback mechanisms
- **Learning:** Robust error handling is essential

**5. Result Presentation:**
- **Challenge:** Making technical findings understandable
- **Solution:** Added detailed descriptions and mitigation guides
- **Learning:** Importance of user experience in security tools

### Q19: How would you defend against someone using this tool maliciously?

**Answer:**

**Technical Controls:**
1. **Rate Limiting:**
   - Limit uploads per IP address
   - Implement CAPTCHA for uploads
   - Monitor for abuse patterns

2. **Authentication:**
   - Require user registration
   - Verify identity
   - Track user actions

3. **Access Logging:**
   - Log all APK uploads
   - Record analysis requests
   - Alert on suspicious patterns

**Legal/Ethical Controls:**
1. **Terms of Service:**
   - Require acceptance of terms
   - Prohibit unauthorized testing
   - Legal disclaimers

2. **User Education:**
   - Prominent ethical use warnings
   - Legal consequences information
   - Responsible disclosure guidance

3. **Reporting Mechanism:**
   - Allow reporting of misuse
   - Cooperation with authorities
   - Blocklist for abuse

**Design Decisions:**
1. **No Exploitation Features:**
   - Only detection, no exploitation
   - No automated attack tools
   - Focus on defensive use

2. **Educational Focus:**
   - Detailed mitigation guidance
   - Security best practices
   - Learning resources

### Q20: What did you learn from this project?

**Answer:**

**Technical Skills:**
- Android application architecture
- Reverse engineering techniques
- Static analysis methodologies
- Web development (Flask, JavaScript)
- Security testing practices
- API design and implementation

**Security Knowledge:**
- Common mobile vulnerabilities
- OWASP Mobile Top 10
- Cryptography best practices
- Secure coding principles
- Risk assessment

**Soft Skills:**
- Project planning and management
- Documentation writing
- Problem-solving
- Research and learning
- Attention to detail

**Key Takeaways:**
1. Security must be built-in, not bolted-on
2. Importance of defense-in-depth
3. User education is as important as tools
4. Ethical responsibility in security work
5. Continuous learning is essential in cybersecurity

---

## Quick Tips for Viva

1. **Be Honest:** If you don't know something, say so and explain how you'd find out
2. **Think Aloud:** Show your thought process when answering
3. **Use Examples:** Reference specific code or scenarios from your project
4. **Stay Calm:** Take a moment to think before answering
5. **Ask for Clarification:** If a question is unclear, ask for clarification
6. **Connect Concepts:** Link your answers to broader security principles
7. **Show Enthusiasm:** Demonstrate interest in the subject
8. **Be Ethical:** Emphasize responsible and legal use throughout

---

Good luck with your viva! 🎓
