# Usage Guide

## Getting Started

This guide will walk you through using the APK Security Scanner to analyze Android applications for security vulnerabilities.

## Step-by-Step Usage

### Step 1: Start the Application

1. **Start Backend Server**
   ```bash
   cd backend
   python app.py
   ```
   Wait for: `* Running on http://0.0.0.0:5000`

2. **Open Frontend**
   - Open `frontend/index.html` in your web browser
   - Or serve via HTTP: `python -m http.server 8000`

### Step 2: Upload APK File

1. **Locate Your APK File**
   - Have the APK file ready on your computer
   - Ensure it's a valid .apk file
   - File size should be under 100MB

2. **Upload Methods**
   
   **Method A: Drag and Drop**
   - Drag the APK file from your file explorer
   - Drop it onto the upload area (blue dashed box)
   - File name will appear below the upload area

   **Method B: Browse and Select**
   - Click "Browse Files" button
   - Navigate to your APK file
   - Select the file and click Open

3. **Verify Selection**
   - File name should be displayed
   - "Start Security Scan" button should become enabled
   - You can click the X to remove and choose a different file

### Step 3: Run Security Scan

1. **Start Analysis**
   - Click "Start Security Scan" button
   - Upload area will hide
   - Loading screen will appear

2. **Monitor Progress**
   - Progress bar shows analysis stages:
     * Decompiling APK (20%)
     * Extracting source code (40%)
     * Analyzing AndroidManifest.xml (60%)
     * Scanning for vulnerabilities (80%)
     * Generating report (100%)
   
3. **Wait for Completion**
   - Typical analysis time: 10-60 seconds
   - Do not close the browser window
   - Do not refresh the page

### Step 4: Review Results

Once analysis completes, you'll see:

1. **Summary Statistics**
   - Four colored boxes showing:
     * High Risk issues (Red) - Critical vulnerabilities
     * Medium Risk issues (Yellow) - Important issues
     * Low Risk issues (Blue) - Minor concerns
     * Total Issues (Green) - All findings

2. **Detailed Vulnerability List**
   Each vulnerability card shows:
   - **Title**: Name of the vulnerability
   - **Risk Badge**: HIGH/MEDIUM/LOW severity
   - **Description**: What the issue is and why it matters
   - **Location**: Where in the app the issue was found
   - **Mitigation**: How to fix the vulnerability

### Step 5: Download Report

1. **Generate Report**
   - Click "Download Full Report" button
   - A text file will be downloaded automatically

2. **Report Contents**
   - Executive Summary
   - All vulnerability details
   - Risk classifications
   - Mitigation strategies
   - Security recommendations
   - Best practices guide

3. **Report File Name**
   - Format: `security_report_YYYYMMDD_HHMMSS.txt`
   - Example: `security_report_20250330_143022.txt`

### Step 6: Scan Another APK

1. Click "Scan Another APK" button
2. Upload interface will reappear
3. Previous results will be cleared
4. Repeat the process from Step 2

## Understanding Results

### Risk Levels

**HIGH (Critical)**
- Immediate security threats
- Can lead to data breaches or financial loss
- Requires urgent fixing
- Examples: Hardcoded API keys, weak encryption

**MEDIUM (Important)**
- Significant security concerns
- Should be fixed in next update
- Can be exploited with some effort
- Examples: Insecure storage, debug mode enabled

**LOW (Advisory)**
- Minor security improvements
- Good to fix for best practices
- Lower exploitation risk
- Examples: Missing obfuscation, exported components

### Common Vulnerabilities

1. **Hardcoded API Keys**
   - What: Credentials embedded in code
   - Risk: Unauthorized API access
   - Fix: Use secure key storage (KeyStore)

2. **Weak Encryption**
   - What: Using outdated algorithms (MD5, DES)
   - Risk: Data can be decrypted
   - Fix: Use AES-256, SHA-256

3. **Missing SSL Pinning**
   - What: No certificate validation
   - Risk: Man-in-the-middle attacks
   - Fix: Implement certificate pinning

4. **Insecure Storage**
   - What: Data stored without encryption
   - Risk: Data accessible on rooted devices
   - Fix: Use EncryptedSharedPreferences

5. **Debug Mode Enabled**
   - What: Debuggable flag = true
   - Risk: App can be debugged in production
   - Fix: Set debuggable = false for release

6. **WebView JavaScript**
   - What: JavaScript enabled without validation
   - Risk: XSS attacks possible
   - Fix: Disable JS or implement CSP

7. **Missing Obfuscation**
   - What: Code is easily readable
   - Risk: Easier reverse engineering
   - Fix: Enable ProGuard/R8

8. **Exported Components**
   - What: Components accessible to other apps
   - Risk: Unauthorized access
   - Fix: Set exported = false

## Best Practices for Testing

### Before Testing

1. **Authorization**
   - Only test apps you own
   - Get written permission for third-party apps
   - Never test without authorization

2. **Preparation**
   - Download APK from official sources
   - Verify APK integrity
   - Keep APK version documented

3. **Environment**
   - Use isolated testing environment
   - Don't test on production servers
   - Keep test data separate

### During Testing

1. **Documentation**
   - Take screenshots of results
   - Save all generated reports
   - Note the app version tested

2. **Validation**
   - Cross-verify findings manually
   - Check for false positives
   - Test fixes in development environment

3. **Responsibility**
   - Don't exploit found vulnerabilities
   - Report findings to app developers
   - Follow responsible disclosure

### After Testing

1. **Remediation**
   - Prioritize HIGH risk issues
   - Create fix timeline
   - Implement suggested mitigations

2. **Re-testing**
   - Test after implementing fixes
   - Verify vulnerabilities are resolved
   - Perform regression testing

3. **Continuous Security**
   - Include in CI/CD pipeline
   - Regular security audits
   - Stay updated on new threats

## Tips for Effective Analysis

### Getting Accurate Results

1. **Use Production APKs**
   - Test the same version users have
   - Use signed release builds
   - Avoid debug builds for production testing

2. **Understand Context**
   - Some findings may be acceptable based on app purpose
   - Consider threat model
   - Evaluate actual risk in your scenario

3. **Combine with Other Tools**
   - Use multiple security testing tools
   - Perform manual code review
   - Conduct penetration testing

### Interpreting Results

1. **False Positives**
   - Not all findings are actual vulnerabilities
   - Verify in source code
   - Consider app architecture

2. **Context Matters**
   - Exported component may be intentional
   - Some storage may not be sensitive
   - Evaluate based on data classification

3. **Priority Setting**
   - Fix HIGH risks first
   - Consider exploitation likelihood
   - Factor in impact if exploited

## Demo Mode

If APKTool/JADX are not installed, the system runs in demo/simulation mode:

- Uses predefined vulnerability patterns
- Demonstrates tool functionality
- Educational purposes only
- Results are simulated

To get real analysis:
1. Install APKTool and JADX
2. Ensure they're in system PATH
3. Restart the backend server

## Troubleshooting

### Upload Issues

**Problem:** Can't upload APK file

**Solutions:**
- Verify file has .apk extension
- Check file size (max 100MB)
- Ensure backend server is running
- Check browser console for errors

### Analysis Failures

**Problem:** Analysis doesn't complete

**Solutions:**
- Check backend logs for errors
- Verify APK file is not corrupted
- Ensure sufficient disk space
- Try with a smaller APK file

### No Results Displayed

**Problem:** Results don't appear after analysis

**Solutions:**
- Check browser console for errors
- Verify backend returned valid JSON
- Clear browser cache
- Try different browser

### Download Issues

**Problem:** Can't download report

**Solutions:**
- Check browser download settings
- Ensure pop-ups are not blocked
- Try using download button again
- Check backend reports folder

## Advanced Usage

### Batch Testing

For multiple APKs:
1. Test each APK individually
2. Download and save each report
3. Compare results across versions
4. Track improvements over time

### Custom Configuration

Edit configuration files to:
- Adjust file size limits
- Add custom security checks
- Modify risk classifications
- Customize report format

### Integration

Integrate with development workflow:
- Add to build pipeline
- Automate testing on commits
- Generate reports for QA team
- Track metrics over time

## Getting Help

1. **Read Documentation**
   - Installation guide
   - Project report
   - README file

2. **Check Logs**
   - Backend console output
   - Browser console errors
   - System error messages

3. **Verify Setup**
   - All dependencies installed
   - Servers running correctly
   - Proper file permissions

---

**Remember:** This tool is for educational and authorized testing only. Always act ethically and legally when performing security testing.
